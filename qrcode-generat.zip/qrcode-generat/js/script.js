let qrbtn = document.querySelector('.qrgenerat');
qrbtn.addEventListener('click', function(){
	
	let website = document.getElementById("website").value;
	let qrcodeContainer = document.getElementById("qrcode");
	 qrcodeContainer.innerHTML = "";
	 
	new QRCode(qrcodeContainer, website); 
	
	document.getElementById("qrcode-container").style.display = "block";
	
	 
});