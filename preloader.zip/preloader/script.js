let getpreload = document.getElementById("preload");

window.addEventListener("load", function(){
	
	setTimeout(function(){
		getpreload.style.display = "none";
	}, 3000);

});