# countdown timer javascript

A Pen created on CodePen.io. Original URL: [https://codepen.io/fghty/pen/KKmRWOa](https://codepen.io/fghty/pen/KKmRWOa).

