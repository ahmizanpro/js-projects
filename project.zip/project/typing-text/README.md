# Typing text

A Pen created on CodePen.io. Original URL: [https://codepen.io/RajTemplate/pen/zYwdKbq](https://codepen.io/RajTemplate/pen/zYwdKbq).

