# Age calculator

A Pen created on CodePen.io. Original URL: [https://codepen.io/fghty/pen/GRmGgOY](https://codepen.io/fghty/pen/GRmGgOY).

