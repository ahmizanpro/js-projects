let header = document.querySelector('.header');

window.addEventListener('scroll', function(){
let value = window.scrollY;

header.classList.toggle("sticky", value > 100);

});