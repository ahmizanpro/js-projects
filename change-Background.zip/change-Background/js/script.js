const colorbox1 = document.querySelector('.color-1');
const colorbox2 = document.querySelector('.color-2');
const colorbox3 = document.querySelector('.color-3');
const imagebox = document.querySelector('.img-box');
const colors = ['#e01245', '#009688', '#3f51b5'];

colorbox1.addEventListener('click', function(){
     imagebox.style.backgroundColor = colors[0];
});

colorbox2.addEventListener('click', function(){
     imagebox.style.backgroundColor = colors[1];
});

colorbox3.addEventListener('click', function(){
     imagebox.style.backgroundColor = colors[2];
});



