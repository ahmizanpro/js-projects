# HTML, CSS, & Javascript-100-days-of-code-challenge :
 - ### Day 1 : Making a simple Image Slider.(not hosted)
 - ### Day 2 : Making a simple to do list.
    - Demo : https://codepen.io/MehdiAoussiad/full/jOqxydp
 - ### Day 3 : Simple music player. (not hosted)
 - ### Day 4 : Email Generator.(using ajax xmlhttprequest to get data from an api).
    - Demo : https://codepen.io/MehdiAoussiad/full/QWNxjNp
 - ### Day 5 : Tabs Project with Popups images. 
    - Demo : https://codepen.io/MehdiAoussiad/full/VwadEPQ
 - ### Day 6 : Making a Simple Notes App. 
    - Demo : https://codepen.io/MehdiAoussiad/full/rNerypg
 - ### Day 7 : Loading animation. 
    - Demo : https://codepen.io/MehdiAoussiad/full/JjXaPgO
 - ### Day 8 : Making a Simple Movie app using an external Api. 
    - Demo: https://codepen.io/MehdiAoussiad/full/rNeZKGa
 - ### Day 9 : Making a simple typing Game. 
    - Demo : https://codepen.io/MehdiAoussiad/full/NWNObyO
 - ### Day 10 : Making a countdown Timer. 
    - Demo : https://codepen.io/MehdiAoussiad/full/gOrooxJ
 - ### Day 11 : Making a simple Calculator with javascript. 
    - Demo :  https://codepen.io/MehdiAoussiad/full/mdPQdvv
 - ### Day 12 : Making a Github Profiles project that search for github users by using the github api. 
    - Demo : https://codepen.io/MehdiAoussiad/full/mdPQxbq
 - ### Day 13 : Making a Password Generator Project. 
    - Demo : https://codepen.io/MehdiAoussiad/full/WNwLpLo
 - ### Day 14 : Simple Background Changer : 
    - Demo : https://codepen.io/MehdiAoussiad/full/vYGvqRe
 - ### Day 15 : Questions Project (FAQ) : 
    - Demo : https://codepen.io/MehdiAoussiad/full/MWyLXBG
 - ### Day 16 : Simple Form Validation. 
    - Demo : https://codepen.io/MehdiAoussiad/full/OJNqbgV
 - ### Day 17 : Loading Animation  
    - Demo : https://codepen.io/MehdiAoussiad/full/poyYOpo
 - ### Day 18 : Auto Text  
    - Demo : https://codepen.io/MehdiAoussiad/pen/BaKENZa
 - ### Day 19 : Theme toggler  
    - Demo : https://codepen.io/MehdiAoussiad/full/WNwWKBJ
 - ### Day 20 : Building a Rock Paper Scissors Game. 
    - Demo : https://codepen.io/MehdiAoussiad/full/vYGwyya
 - ### Day 21 : Random Jokes with fetch using Async await syntax. 
    - Demo : https://codepen.io/MehdiAoussiad/full/oNxRVrN
 - ### Day 22 : KeyCodes app with vanilla Javascript.
    - Demo : https://codepen.io/MehdiAoussiad/pen/OJNezdQ
 - ### Day 23 : Infinite Scroll.
    - Demo : https://codepen.io/MehdiAoussiad/full/mdPNybJ
 - ### Day 24 : Simple Gsap Animation.
    - Demo : https://codepen.io/MehdiAoussiad/full/xxVvLmx
 - ### Day 25 : Side Navigation.
    - Demo : https://codepen.io/MehdiAoussiad/full/JjXgwvg
 - ### Day 26 : Locale Storage Example.
    - Demo : https://codepen.io/MehdiAoussiad/full/gOMYWxX
 - ### Day 27 : Meal Generator with vanilla JS using Fetch.
    - Demo : https://codepen.io/MehdiAoussiad/full/bGebPPd
 - ### Day 28 : Skills bar.
    - Demo : https://codepen.io/MehdiAoussiad/full/oNLNdwJ
 - ### Day 29 : Loading Buttons.
    - Demo : https://codepen.io/MehdiAoussiad/full/KKMwggz
 - ### Day 30 : User Filter.
    - Demo : https://codepen.io/MehdiAoussiad/full/VwjYqWG
 - ### Day 31 : Hidden User.
    - Demo : https://codepen.io/MehdiAoussiad/full/bGedEJE
 - ### Day 32 : Simple Typing Speed game with vanilla Javascript.
    - Demo : https://codepen.io/MehdiAoussiad/full/XWKmJMj
 - ### Day 33 : Hotel Reservation Design.
    - Demo : https://codepen.io/MehdiAoussiad/full/yLJYROg
 - ### Day 34 : Text Highlight.
    - Demo : https://codepen.io/MehdiAoussiad/full/WNxroGv
 - ### Day 35 : Color Picker with Html,Css, and Vanilla JS.
    - Demo : https://codepen.io/MehdiAoussiad/full/OJXMGaB
 - ### Day 36 : 404 Page Design.
    - Demo : https://codepen.io/MehdiAoussiad/full/OJXNQEe
 - ### Day 37 : Procrastination again.
 - ### Day 38 : HTML email design.
    - Demo : https://codepen.io/MehdiAoussiad/full/yLJJJwK
 - ### Day 39 : Image Slider.
    - Demo : https://codepen.io/MehdiAoussiad/full/OJXXeMK
 - ### Day 40 : Incrementing Counter.
    - Demo : https://codepen.io/MehdiAoussiad/full/LYZRdeJ
 - ### Day 41 : Simple tooltip.
    - Demo : https://codepen.io/MehdiAoussiad/full/ZEOBNxd
 - ### Day 42 : Simple Clock using moment.js.
    - Code Demo : https://github.com/Aoussiad-Mehdi/Clock-using-moment.js   
 - ### Day 43 : Rotation Slideshow with HTML and CSS.
    - Demo : https://codepen.io/MehdiAoussiad/full/WNxpxrY
 - ### Day 44 : Procrastination.
 - ### Day 45 : Simple Newsletter Design.
    - Demo : https://codepen.io/MehdiAoussiad/full/NWrgeYV
 - ### Day 46 : Simple Image Upload.
    - Demo : https://codepen.io/MehdiAoussiad/full/abZqJWP  
 - ### Day 47 : User Card Design.
    - Demo : https://codepen.io/MehdiAoussiad/full/bGevxMw
 - ### Day 48 : Blur Animation HTML CSS & JS
    - Demo : https://codepen.io/MehdiAoussiad/full/wvWjBmM
 - ### Day 49 : Line through effect.
    - Demo : https://codepen.io/MehdiAoussiad/full/PozaYBp
 - ### Day 50 : Lazy loading images with the intersection observer API.
    - Demo : https://codepen.io/MehdiAoussiad/full/KKMeoyJ
 - ### Day 51 : User Card Design HTML & CSS.
    - Demo : https://codepen.io/MehdiAoussiad/full/PozBgNa
 - ### Day 52 : Reviews Design HTML & CSS.
    - Demo : https://codepen.io/MehdiAoussiad/full/gOMBrzN
 - ### Day 53 : Send Love Button HTML CSS & JavaScript.
    - Demo : https://codepen.io/MehdiAoussiad/full/yLJQzxO
 - ### Day 54 : Feedback UI Design HTML CSS & JS.
    - Demo : https://codepen.io/MehdiAoussiad/full/KKMbGBO
 - ### Day 55 : UI Design HTML & CSS.
    - Demo : https://codepen.io/MehdiAoussiad/full/RwRdPWG
 - ### Day 56 : Find It.
    - Demo : https://codepen.io/MehdiAoussiad/full/KKMEBxp
 - ### Day 57 : Adding the dark mode to my static website.
    - Demo : https://aoussiad-mehdi.github.io/Morocco-traveling-website/#
   
 - ### Day 58 : First React App (Books).
    - Demo : https://react-ebay-books.netlify.app/
    
- ### Day 59 : Vanilla JavaScript Drum Kit.
    - Demo : https://codepen.io/MehdiAoussiad/full/PoGwYwe
  
- ### Day 60 : Vanilla JS Hover board.
    - Demo : https://codepen.io/MehdiAoussiad/full/BaLyvBz
- ### Day 61 : Blog Posts Design HTML & CSS.
    - Demo : https://codepen.io/MehdiAoussiad/full/vYXOqez
    
- ### Day 62 : Traffic Lights.
    - Demo : https://codepen.io/MehdiAoussiad/full/MWjeoLM
    
- ### Day 63 : Live counting views by using the countAPI.
    - Demo : https://codepen.io/MehdiAoussiad/full/BaLQpyK
    
- ### Day 64 : Simple React counter.
    - Demo: https://github.com/Aoussiad-Mehdi/Simple-React-counter
- ### Day 65 : Simple React To-do list.

- ### Day 66 : BattleCSS face challenge.
    - Demo: https://codepen.io/MehdiAoussiad/full/yLaPzJX
    
- ### Day 67 : Rain Drops HTML CSS & JS.
    - Demo: https://codepen.io/MehdiAoussiad/full/VwKyYQQ
    
- ### Day 68 : Currency Converter.
    - Demo: https://codepen.io/MehdiAoussiad/full/xxEpprR
    
- ### Day 69 : Simple Image Slider with HTML CSS & JavaScript.
    - Demo: https://codepen.io/MehdiAoussiad/full/gOweYZN
    
- ### Day 70 : Digital Clock using HTML, CSS, and Vanilla JavaScript.
    - Demo: https://codepen.io/MehdiAoussiad/full/BaLVpab
    
- ### Day 71 : Simple Like Button Design.
    - Demo: https://codepen.io/MehdiAoussiad/full/gOwjXZy
    
- ### Day 72 : Contact form using HTML & CSS.
    - Demo: https://codepen.io/MehdiAoussiad/full/qBaMwmK
    
- ### Day 73 : Drag and Drop HTML CSS & JavaScript.
    - Demo: https://codepen.io/MehdiAoussiad/full/bGwOwyb
    
- ### Day 74 : Simple user birthdays using React(with useState).
    - Demo: https://csb-wpt9y.netlify.app/
    
- ### Day 75 : Simple reviews slider using React.
    - Demo: https://csb-tgwxf.netlify.app/

- ### Day 76 : Simple ReactJs Tours Project.
   - Demo: https://suspicious-mayer-6adcd2.netlify.app/

- ### Day 77 : Simple accordion using ReactJS.
   - Demo: https://codesandbox.io/s/sharp-wind-p0m0v?file=/src/App.js

- ### Day 78 : Popup Modal using ReactJS.
   - Demo: https://csb-dimm8.netlify.app/  
    
    
    
    
  
