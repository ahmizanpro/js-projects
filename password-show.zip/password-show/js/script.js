let password = document.getElementById('password');
let toggler = document.getElementById('toggler');

toggler.addEventListener('click', function(){
	
if(password.type == 'password'){
	
	password.setAttribute('type', 'text');
	toggler.classList.remove("fa-eye-slash");
	toggler.classList.add("fa-eye");
   
}else{
	password.setAttribute('type', 'password');
	toggler.classList.remove("fa-eye");
	toggler.classList.add("fa-eye-slash");
	
}	
	
});