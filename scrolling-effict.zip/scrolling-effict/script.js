let imgbg = document.querySelector('.img-bg');
window.addEventListener('scroll', function() {
     let value = window.scrollY;
    imgbg.style.clipPath = "circle("+value+"px at center)";
i
});