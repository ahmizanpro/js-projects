let menu = document.querySelector('.menu');
let toggle = document.querySelector('.toggle');

toggle.addEventListener('click', function(){
	menu.classList.toggle('active');
});