const panels = document.querySelectorAll(".panel");
const change = document.getElementById("mode");
let selector = document.body;

panels.forEach(panel => {
	panel.addEventListener('click',function(){
		 removingActiveClass();
		 panel.classList.add('active');
	});

});

function removingActiveClass() {	
    panels.forEach(panel => {
        panel.classList.remove('active');
    })
}


change.addEventListener('click',function(){
		selector.classList.toggle('dark-mode');
	});