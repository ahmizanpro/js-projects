// making a function which will toggle the class
function toggleNewsletter(){
    const newsletter = document.getElementById("newsletter");
    newsletter.classList.toggle("active");
}
