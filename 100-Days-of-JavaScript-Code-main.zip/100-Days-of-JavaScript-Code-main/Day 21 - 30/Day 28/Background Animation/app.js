for (let i = 1; i < 2000; i++) {
  const shape = document.createElement("span");
  document.querySelector(".container").appendChild(shape);
}
