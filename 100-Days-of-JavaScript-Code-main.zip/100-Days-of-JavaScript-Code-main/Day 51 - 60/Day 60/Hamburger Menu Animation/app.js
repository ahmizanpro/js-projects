const container = document.querySelector(".container");

container.addEventListener("click", () => {
  container.classList.toggle("open");
});
